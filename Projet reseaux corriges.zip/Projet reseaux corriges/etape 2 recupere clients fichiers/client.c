#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char* nom;
	int taille;
} fichier;

typedef struct {
	char* adresse;
	short port;
	int nbfichiers;
	fichier* fichiers
} client;

int nbclient = 0;

int main(int argc,char** argv){
if (argc!=3){
	printf("Nombre de parametres incorrects ! Utilisation : nomprog ip port\n");
	return -1;
}


int dSock=socket(PF_INET,SOCK_STREAM,0);// je creer la socket de mon coté
if (dSock<0) {
	printf("Erreur lors de la creation de la socket ! ");
	return -1;
}

struct sockaddr_in adR;// création de ladresse
adR.sin_family=AF_INET;
adR.sin_port=htons(atoi(argv[2])); // le port du serveur est a passé en parametre

int res =inet_pton(AF_INET,argv[1],&(adR.sin_addr));//On va stocker l'adresse sous forme réseau , passe en parametre
if (res!=1) {
	printf("Erreur lors du stockage de l'adresse !");
	return -1;
}


socklen_t lgAd=sizeof(adR);
int conn=connect(dSock,(struct sockaddr *) &adR,lgAd);// je me connecte a la socket du server 
if (conn == -1){
	printf("Erreur lors de la connection !");
	return -1;
}

	int ping=2;
int resping=send(dSock,&ping,sizeof(int),0);//je ping le serveur pour qu'il m'envoie la liste client + fichiers (le 2 est just le "flag" du ping)
if (resping == -1){
	printf("Erreur lors de l'envoi du port ! ");
	return -1;
}

int resnbcl=recv(dSock,nbclient,sizeof(nbclient),0);//buffer pret je peux recevoir le nombre de clients
if (resnbcl == -1){
	printf("Erreur lors de la reception du nombre de client !");
	return -1;
}

struct client clients[nbclient];

for (int i=0;i<nbclient;i++){

struct client c1;

	char * adresse;

int ad=recv(dSock,&adresse,sizeof(adR.sin_addr.s_addr),0);//buffer pret je peux recevoir l'adresse du peer
if (ad==-1){
	printf("Erreur lors de la reception de l'adresse !");
	return -1;
}	

c1.adresse=adresse;

short porttemp;

int p=recv(dSock,&porttemp,sizeof(porttemp),0);//buffer pret je peux recevoir le port du peer
if (p==-1){
	printf("Erreur lors de la reception du port !");
	return -1;
}	

c1.port=porttemp;

int nbfictemp;
int f=recv(dSock,&nbfictemp,sizeof(nbfictemp),0);//buffer pret je peux recevoir le nb de fichiers
if (f==-1){
	printf("Erreur lors de la reception du nb de fichiers!");
	return -1;
}

c1.nbfichiers=nbfictemp;	

for (int j=0;j<nbfictemp; j++){
	struct fichier f1;
	int taillenomfic;

int tnf=recv(dSock,&taillenomfic,sizeof(int),0);//buffer pret je peux recevoir la taille du nom de mon fichier i
if (tnf==-1){
	printf("Erreur lors de la reception du nb de fichiers!");
	return -1;
}
	
	char nomfic1[taillenomfic];

	int nmfic=recv(dSock,&nomfic1,taillenomfic,0);//buffer pret je peux recevoir le nom du fichier i
if (nmfic==-1){
	printf("Erreur lors de la reception de l'adresse !");
	return -1;
}

	f1.nom = nomfic1;


	int tailletotale;

int etf=recv(dSock,&tailletotale,sizeof(int),0);//buffer pret je peux recevoir la taille du fic
if (etf==-1){
	printf("Erreur lors de la reception du nb de fichiers!");
	return -1;
}

	f1.taille=tailletotale;

	c1.fichiers[j]=f1;
}//fin du for fichiers

	clients[i]=c1;
}//fin chaque client


close(dSock);//je ferme la socket car communication terminée

	return 0;
}