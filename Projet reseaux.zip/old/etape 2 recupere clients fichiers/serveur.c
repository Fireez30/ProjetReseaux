#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
        char* nom;
        int taille;
} fichier;

typedef struct {
        char* adresse;
        short port;
        int nbfichiers;
        fichier* fichiers;
} client;

int nbclient = 0;
client* clients;

int main(int argc,char** argv){
    if (argc!=1){
        printf("Paramètres incorrects ! ");
        return -1;
    }

    int nbclient = 0;
    client* clients;


    int dSock=socket(PF_INET,SOCK_STREAM,0);//Crée la socket, si ca ne marche pas s'arrete
    if (dSock<0) {
        printf("Erreur lors de la creation de la socket ! ");
        return -1;
    }

    struct sockaddr_in adR;// tout ca sert a bien ta socket correctement  , adR est la structure de l'adresse
    adR.sin_family=AF_INET;// ca doit rester comme ca
    adR.sin_port=htons(port);// passe le port en version reseau et le stock
    adR.sin_addr.s_addr = INADDR_ANY; // ladresse est déterminée par le systeme

    int res1=bind(dSock,(struct sockaddr *) &adR,sizeof(adR));//bind la socket
    if (res1==-1){
        printf("Erreur du bind \n");
        return -1;
    }

    listen(dSock,2);//met la socket en attente de requete endors le serveur

    struct sockaddr_in adClient;//si un client arrivé je vais devoir stocker son adresse
    socklen_t lgA = sizeof(struct sockaddr_in);

    while (true) {

        int dSClient=accept(dSock,(struct sockaddr *) &adClient,&lgA);// jaccepte la demande du client et je stocke son adresse dans adClient
       

        int ping;
        int resping=recv(dSock,&ping,sizeof(int),0);//buffer pret je peux recevoir le nb de fichiers
        if (resping==-1){
        printf("Erreur lors de la reception du ping!");
        return -1;
}

        if (ping == 2){

        int resnbcl=send(dSock,&nbclients,sizeof(int),0);//j'envoie le nb de clients connectés au serveur
        if (res4 == -1){
        printf("Erreur lors de l'envoi de la taille du nombre de clients ! ");
        return -1;
        }

        for(int i=0;i<nbclient;i++){//pour chaque client

int resadr=send(dSock,&clients[i].adresse,sizeof(clients[i].adresse),0);//j'envoie son adresse
    if (resadr == -1){
    printf("Erreur lors de l'envoi de l'adresse' ! ");
    return -1;
}

int resport=send(dSock,&clients[i].port,sizeof(clients[i].port),0);//j'envoie son port
if (resport == -1){
    printf("Erreur lors de l'envoi du port ! ");
    return -1;
}

int resnbficc=send(dSock,&clients[i].nbfichiers,sizeof(clients[i].nbfichiers),0);//j'envoie son nombre de fichiers
if (resnbficc == -1){
    printf("Erreur lors de l'envoi du nombre de fichiers ! ");
    return -1;
}

for (int j=0;j<clients[i].nbfichiers;j++){
    
    int taillenmfic = sizeof(clients[i].fichiers[j].nom);
    int restnf=send(dSock,&ntaillenmfic,sizeof(int),0);//j'envoie la taille du nom du fic
if (restnf == -1){
    printf("Erreur lors de l'envoi de la taille du nom ! ");
    return -1;
}

int resnmf=send(dSock,&clients[i].fichiers[j].nom,sizeof(clients[i].fichiers[j].nom),0);//j'envoie son nom
    if (resnmf == -1){
    printf("Erreur lors de l'envoi de l'adresse' ! ");
    return -1;
}

    int restfic=send(dSock,clients[i].fichiers[j].taille,sizeof(int),0);//j'envoie la taille  du fic
if (restfic == -1){
    printf("Erreur lors de l'envoi de la taille du fic du peer! ");
    return -1;
}


}




       
        }
    }
}

    close(dSock);
    
    return 0;
}
